# Denne øvelse er vist lidt for kryptisk.
# Så glem den bare.

# Hvis i har fundet en løsning så kigger vi på den på torsdag, ellers glem denne øvelse.


